window.addEventListener("load", function(e) {
    _listen();
    _endListen();
});

/**
 * 1. Création d'une fonction.
 * 2. Récupération des ID.
 * 3. On appelle la fonction de vérification.
 */
function _recup(){
    
    let id = document.getElementById("0");
    let mdp= document.getElementById("1");


    if(id && mdp){
        _verif(id, mdp);
    }else{
        console.log("Search...",);
    }
}

function _verif(idVerif, mdpVerif){

    /** La regEx vérifie qu'il n'y a pas de caractère spéciaux dans l'ID */
    let tracking = new RegExp(/[!' '`@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/);
    let infoMatch = document.getElementById("2");
    
    if(idVerif.value != '' && mdpVerif.value != ''){
        if(idVerif.value.match(tracking) != null){
            infoMatch.innerHTML = "Votre identifiant contient des caractère spéciaux";    
            return;
        }else{
            infoMatch.innerHTML = "We good";
        }
        /** Regex les séquences de caractère entre quote et double quote */
        tracking = new RegExp(/('[a-zA-Z0-9 =]*')|("[a-zA-Z0-9 =]*")| /);
        if(mdpVerif.value.match(tracking) != null){
            infoMatch.innerHTML = "Vos identifiants sont incorrecte";
        console.log("Non conforme");  
            return;
        }else{
            infoMatch.innerHTML = "We good mdp";
        console.log("OK");
        }
    }else
    {
        infoMatch.innerHTML = "Veuillez entrer vos identifiant";
        console.log("Search...");
    }
}

function _listen(){

    /** On crée une variable qui récupère l'ID */
    let formVerif = document.getElementById('myForm');

    /** On crée une expression de fonction qui prends 'e' comme paramètre 
     * Expression de fonction EXEMPLE " const goRecup = (e) => "
     * Cette expression prends en paramètre sur le "e" un "preventDefault" qui empêche l'envoi du formulaire
     * Le second paramètre est la fonction _recup();
    */
    let goRecup = (e) => { e.preventDefault();  _recup(); };
    formVerif.addEventListener("click", goRecup);

}

function _endListen(e){
    
    let formVerif = document.getElementById('myForm');

    let backRecup = () => _recup();
    formVerif.removeEventListener("click", backRecup);

}